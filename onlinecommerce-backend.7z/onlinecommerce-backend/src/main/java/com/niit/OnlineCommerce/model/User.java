package com.niit.OnlineCommerce.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
@Entity
@Table
@Component
public class User  {
	@Id
	private String id;
	@Min(4)
	@Max(15)
	private String password;
	@NotEmpty(message="Please enter your name")
	private String name; 
	
	@Column( unique=true, nullable=false)
	private String mail;
	private String role;
	private int MobileNumber;
	
}
