package com.niit.OnlineCommerce.dao;

import java.util.List;

import com.niit.OnlineCommerce.model.Product;

public interface ProductDAO {
 public void addProduct(Product product);
 public void updateProduct(Product product);
 public void deleteProduct(Product product);
 public Product getproductById(int id);
 public List<Product> listproducts();
 public List<Product> getProductsByCategory(String category);	
}
