package com.niit.OnlineCommerce.dao;

public interface CategoryDAO {

}
