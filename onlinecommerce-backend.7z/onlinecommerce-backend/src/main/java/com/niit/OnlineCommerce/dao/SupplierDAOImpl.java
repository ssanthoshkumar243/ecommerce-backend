package com.niit.OnlineCommerce.dao;

import java.util.List;

import com.niit.OnlineCommerce.model.Supplier;

public class SupplierDAOImpl implements SupplierDAO{

	public void addSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		
	}

	public void deleteSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		
	}

	public void updateSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		
	}

	public List<Supplier> listsuppliers() {
		// TODO Auto-generated method stub
		return null;
	}

	public Supplier getSupplierById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
