package com.niit.OnlineCommerce.model;

public class Category {
	
	private int categoryId;
	private String categoryName;
	private String description;	
	
}
