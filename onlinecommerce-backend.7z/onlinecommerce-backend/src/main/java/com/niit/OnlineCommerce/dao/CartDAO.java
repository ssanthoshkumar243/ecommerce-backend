package com.niit.OnlineCommerce.dao;

public interface CartDAO {

}
