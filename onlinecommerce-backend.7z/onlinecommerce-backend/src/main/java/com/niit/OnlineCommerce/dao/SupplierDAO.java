package com.niit.OnlineCommerce.dao;

import java.util.List;

import com.niit.OnlineCommerce.model.Supplier;

public interface SupplierDAO {
	public void addSupplier(Supplier supplier);
	public void deleteSupplier(Supplier supplier);
	public void updateSupplier(Supplier supplier);
	public List<Supplier> listsuppliers();
	public Supplier getSupplierById(int id);	

}
