package com.niit.OnlineCommerce.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.niit.OnlineCommerce.model.Product;

@Transactional
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	public SessionFactory sessionFactory;
	
	public void addProduct(Product product) 
	{
		Session session= sessionFactory.getCurrentSession();
		session.saveOrUpdate(product);	
	}

	public void updateProduct(Product product) {
		Session session=sessionFactory.getCurrentSession();
		session.saveOrUpdate(product);
		
	}

	public void deleteProduct(Product product) {
		Session session=sessionFactory.getCurrentSession();
		session.delete(product);
	}

	public Product getproductById(int id) {
		
		return null;
	}

	public List<Product> listproducts() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Product> getProductsByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

}
